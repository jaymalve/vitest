# ci-sdk

Insanely fast CI. No migration. By [Diffling](https://diffling.com).

## scan

See where your GitHub Actions minutes and dollars go, and how much ci-sdk would save. Run it in your repo:

```bash
npx ci-sdk scan
```

- Looks at the last 30 days of workflow runs (`--days`, `--max-runs` to change).
- Estimates savings from your repo's own history: repeated runs, tests a change could not reach (via an oxc import graph), and slow installs.
- `--markdown` for a PR or Slack, `--json` for tooling.
- Needs a GitHub token with **Actions: read**. Uses `GITHUB_TOKEN`, `GH_TOKEN`, or `gh auth token`.
- Runs locally. Your code and CI data never leave your machine.

## test

Run only the tests your changes can reach, using each package's own `test` script:

```bash
npx ci-sdk test
```

- Looks at uncommitted and untracked changes. Add `--since origin/main` to include commits on your branch.
- `--list` prints the affected test files instead of running them.
- Follows imports through barrel files, so a change in a shared package only runs the tests that use it.
- If a change can affect everything, such as a root config, it runs the full suite.

Needs Node 22.18 or newer.
